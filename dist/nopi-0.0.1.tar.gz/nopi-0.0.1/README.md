# nopi
New Orleans Programming Interface (NOPI)


## Currently adding
* https://library.municode.com/la/new_orleans


## Future additions
* https://datadriven.nola.gov/home/


### Reference Material
I have referenced https://github.com/openstates/openstates-scrapers/tree/master/scrapers/la
as a starting point.
